COMPLETE EXAMINATION PROJECTS - 2026

CONTENTS
1. Question1_ProductSalesReport - independent Java console application for Question 1.
2. Question2_MattressSalesGUI - independent Java Swing GUI application for Question 2.

Each question is a separate Maven NetBeans project. Open each project separately using NetBeans: File > Open Project, then select the relevant question folder. Both projects use Java 17 or newer and JUnit 5 for the required unit tests. NetBeans/Maven will need internet access the first time to download the JUnit and Maven build dependencies.

QUESTION 1
Uses a one-dimensional product-name array and a two-dimensional array containing each product's sales for three months. Product implements IProducts. PrintProduct prints the report. The average follows the supplied sample output: total sales divided by the nine product/month entries. The most popular product is determined by the highest combined three-month sales.

QUESTION 2
Uses Swing controls and the required File and Tools menus. ProductCalculations implements IProductCalculations. Successful processing displays the calculated values and appends the sale record to data.txt in the project's working directory. Clear resets the form and sets the product selection to index 0.

VERIFICATION NOTES
The Java source files were compiled with the Java compiler available in the build environment. The JUnit test source files are included, but the Maven/JUnit test runner could not be executed in the build environment because Maven is not installed there. Run the included tests in NetBeans after Maven dependencies have loaded. The Swing window requires a graphical desktop, so visual interaction was not automated in this environment.
