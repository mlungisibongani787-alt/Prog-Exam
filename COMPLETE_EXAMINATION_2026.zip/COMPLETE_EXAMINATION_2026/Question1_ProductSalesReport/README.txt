QUESTION 1 - PRODUCT SALES REPORT

Project type: Java Maven application
Main class: za.ac.iie.question1.Main
Java version: 17 or newer

OPEN IN NETBEANS
1. Extract the examination ZIP file.
2. Open Apache NetBeans.
3. Select File > Open Project.
4. Select the Question1_ProductSalesReport folder.
5. Allow NetBeans to load the Maven project and its JUnit dependency.
6. Run the project. Enter the sales for each of the three products for months 1, 2 and 3.

The report displays the total sales, average sales per product/month entry, and the product with the highest combined sales over the three months.

UNIT TESTS
The test package contains the two tests specified in Question 1. Run them from the Test Files option in NetBeans or with: mvn test
