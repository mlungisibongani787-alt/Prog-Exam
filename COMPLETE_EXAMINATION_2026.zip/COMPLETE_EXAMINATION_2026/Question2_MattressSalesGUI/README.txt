QUESTION 2 - MATTRESS SALES GUI

Project type: Java Swing Maven application
Main class: za.ac.iie.question2.Main
Java version: 17 or newer

OPEN IN NETBEANS
1. Extract the examination ZIP file.
2. Open Apache NetBeans.
3. Select File > Open Project.
4. Select the Question2_MattressSalesGUI folder.
5. Allow NetBeans to load the Maven project and its JUnit dependency.
6. Run the project. Enter a customer name, choose a mattress, enter its price and select PROCESS.

The application calculates VAT at 15%, commission at 5%, and the total (price + VAT + commission). Each successful sale is appended to data.txt in the project's working directory. The File > Exit item closes the application. Tools > Process uses the same processing method as the button. Tools > Clear resets the fields and selects the first product.

UNIT TESTS
The test package contains the two tests specified in Question 2. Run them from the Test Files option in NetBeans or with: mvn test
